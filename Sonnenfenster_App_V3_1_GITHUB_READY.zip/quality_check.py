import json, pathlib, sys
root=pathlib.Path(__file__).parent
d=json.loads((root/"data.json").read_text(encoding="utf-8"))
errors=[]; ids=set()
region_ids={r["id"] for r in d["regions"]}
for p in d["places"]:
    if p["id"] in ids: errors.append("Doppelte ID: "+p["id"])
    ids.add(p["id"])
    for k in ("id","region","place","camping","status"):
        if not p.get(k): errors.append(f"{p.get('place','?')}: fehlt {k}")
    if p["region"] not in region_ids: errors.append(p["place"]+": unbekannte Region")
    if not p.get("source_confirmed"): errors.append(p["place"]+": Quelle nicht bestätigt")
print(f"Regionen: {len(d['regions'])} | Plätze: {len(d['places'])} | Fehler: {len(errors)}")
for e in errors: print("FEHLER:",e)
sys.exit(1 if errors else 0)
