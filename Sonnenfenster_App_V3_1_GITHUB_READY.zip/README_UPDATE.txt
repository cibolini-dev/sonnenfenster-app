SONNENFENSTER APP – UPDATE V2 (VORBEREITUNG)

Enthalten:
- skalierbare Struktur Region -> Platz -> Detailfelder
- 12 Regionsgruppen
- 75 vorhandene/erarbeitete Standorte als Masterindex
- Live-Wettermodul für GitHub Pages über Open-Meteo
- Ranking des besten zusammenhängenden 3-Tage-Sonnenfensters der nächsten 10 Tage
- Suche und Regionsfilter
- vorbereitete Felder für PDF, Bild, Maps, Hund, Essen, Wanderungen und Schlechtwetter

Wetterlogik:
- Sonne positiv
- Niederschlagsmenge und -wahrscheinlichkeit negativ
- spätere Prognosetage erhalten eine kleine Vertrauensabwertung
- grün >=75, gelb 55–74, rot <55
- nur Reiseorientierung, keine alpine Sicherheitsprognose

Nächster Ausbau:
- Detailfelder aus den vorhandenen Sonnenfenster-PDFs übernehmen
- pro Platz echte Koordinaten statt nur Regionszentrum
- PDFs/Bilder sauber zuordnen
- Regionsranking später aus den besten konkreten Plätzen berechnen
