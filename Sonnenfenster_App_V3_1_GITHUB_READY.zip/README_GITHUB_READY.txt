SONNENFENSTER APP V3.1 – GITHUB READY
======================================

STATUS
- 73/73 Plätze in der App
- 12 Regionen
- Regions- und Platzsuche
- aufklappbare Detailansichten
- Wetterranking / bestes 3-Tage-Sonnenfenster
- Wetterfilter
- mobile Darstellung
- PWA-Manifest + App-Icons
- Offline-Grundfunktion über Service Worker
- letzte Wetterprognose wird lokal gespeichert und beim nächsten Start angezeigt
- Wetter wird bei Internetverbindung automatisch erneuert, wenn die gespeicherte Prognose älter als 3 Stunden ist

GITHUB-EINBAU
Dieses Paket ist als vollständiger Ersatz des bisherigen App-Inhalts vorbereitet.
Im Repository sollen im Stammverzeichnis diese Dateien liegen:
index.html
styles.css
app.js
data.json
manifest.webmanifest
service-worker.js
icon-192.png
icon-512.png

WICHTIG
Beim Einbau auf GitHub am besten den bisherigen App-Inhalt ersetzen, nicht parallel danebenlegen.
Die vorhandene GitHub-Pages-Einstellung "Deploy from a branch / main / root" kann bestehen bleiben.

HANDY
Nach dem GitHub-Update die neue Website einmal im Browser öffnen.
Ein altes Homescreen-App-Symbol kann wegen der früheren Repository-Adresse noch auf die alte Seite zeigen.
Darum erst nach erfolgreichem GitHub-Test das alte Symbol löschen und die neue V3.1 einmal neu zum Startbildschirm hinzufügen.

WETTER
Open-Meteo wird live aufgerufen. Dafür ist keine API-Zugangsdaten-Datei notwendig.
Bei fehlendem Internet funktioniert die App mit dem zuletzt geladenen Bestand weiter; Wetterdaten werden aus dem lokalen Cache angezeigt, falls schon einmal geladen.

SICHERHEIT
Das Sonnenfenster-Ranking ist eine Reisehilfe. Für Bergtouren bleiben lokale Wetter-, Gewitter-, Weg- und Gefahreninformationen massgebend.
